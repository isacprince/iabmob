package com.example.oceanic

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.oceanic.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)

        val sharedPreferences = requireActivity().getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        val userEmail = sharedPreferences.getString("email", "Usuário")

        binding.tvWelcome.text = "Seja Bem-vindo, $userEmail!"

        binding.btnCadastrarIncidente.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_cadastrarIncidenteFragment)
        }

        binding.btnDoacao.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_doacaoFragment)
        }

        binding.btnListaDoacoes.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_listaDoacoesFragment)
        }

        binding.btnLogoff.setOnClickListener {
            with(sharedPreferences.edit()) {
                putBoolean("isLoggedIn", false)
                apply()
            }
            findNavController().navigate(R.id.action_homeFragment_to_loginFragment)
        }

        return binding.root
    }
}