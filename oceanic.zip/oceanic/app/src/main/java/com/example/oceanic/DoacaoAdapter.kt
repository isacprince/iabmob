package com.example.oceanic

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.oceanic.databinding.ItemDoacaoBinding

data class Doacao(val nome: String, val quantia: Double, val causa: String)

class DoacaoAdapter(private val doacoes: List<Doacao>) : RecyclerView.Adapter<DoacaoAdapter.DoacaoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoacaoViewHolder {
        val binding = ItemDoacaoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DoacaoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DoacaoViewHolder, position: Int) {
        holder.bind(doacoes[position])
    }

    override fun getItemCount(): Int = doacoes.size

    inner class DoacaoViewHolder(private val binding: ItemDoacaoBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(doacao: Doacao) {
            binding.tvNome.text = doacao.nome
            binding.tvQuantia.text = "R$${doacao.quantia}"
            binding.tvCausa.text = doacao.causa
        }
    }
}
