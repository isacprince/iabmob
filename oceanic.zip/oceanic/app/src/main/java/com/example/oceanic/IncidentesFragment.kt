package com.example.oceanic

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.oceanic.databinding.FragmentIncidentesBinding

class IncidentesFragment : Fragment() {
    private lateinit var binding: FragmentIncidentesBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentIncidentesBinding.inflate(inflater, container, false)
        loadIncidents()

        return binding.root
    }

    private fun loadIncidents() {
        val sharedPreferences = requireActivity().getSharedPreferences("Incidentes", Context.MODE_PRIVATE)
        val incidentes = sharedPreferences.getStringSet("incidentes", mutableSetOf()) ?: mutableSetOf()

        incidentes.forEach { incidente ->
            val incidenteData = incidente.split("|")
            val titulo = incidenteData[0]
            val coordenadas = incidenteData[1]
            val descricao = incidenteData[2]
            val status = incidenteData[3]

            val incidenteView = LayoutInflater.from(context).inflate(R.layout.item_incidente, null)
            val tvTitulo = incidenteView.findViewById<TextView>(R.id.tvTitulo)
            val tvCoordenadas = incidenteView.findViewById<TextView>(R.id.tvCoordenadas)
            val tvDescricao = incidenteView.findViewById<TextView>(R.id.tvDescricao)
            val btnResolvido = incidenteView.findViewById<Button>(R.id.btnResolvido)
            val btnSemSucesso = incidenteView.findViewById<Button>(R.id.btnSemSucesso)
            val statusView = incidenteView.findViewById<View>(R.id.statusView)

            tvTitulo.text = titulo
            tvCoordenadas.text = coordenadas
            tvDescricao.text = descricao
            statusView.setBackgroundColor(getStatusColor(status))

            btnResolvido.setOnClickListener {
                updateStatus(incidente, "RESOLVIDO")
                statusView.setBackgroundColor(getStatusColor("RESOLVIDO"))
            }

            btnSemSucesso.setOnClickListener {
                updateStatus(incidente, "SEM SUCESSO")
                statusView.setBackgroundColor(getStatusColor("SEM SUCESSO"))
            }

            binding.incidentesContainer.addView(incidenteView)
        }
    }

    private fun getStatusColor(status: String): Int {
        return when (status) {
            "RESOLVIDO" -> resources.getColor(R.color.green)
            "SEM SUCESSO" -> resources.getColor(R.color.red)
            else -> resources.getColor(R.color.gray)
        }
    }

    private fun updateStatus(incidente: String, status: String) {
        val sharedPreferences = requireActivity().getSharedPreferences("Incidentes", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val incidentes = sharedPreferences.getStringSet("incidentes", mutableSetOf()) ?: mutableSetOf()

        incidentes.remove(incidente)
        val incidenteData = incidente.split("|")
        val updatedIncidente = "${incidenteData[0]}|${incidenteData[1]}|${incidenteData[2]}|$status"
        incidentes.add(updatedIncidente)
        editor.putStringSet("incidentes", incidentes)
        editor.apply()
    }
}
