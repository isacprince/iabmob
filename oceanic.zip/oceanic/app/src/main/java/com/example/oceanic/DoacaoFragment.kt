package com.example.oceanic

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.oceanic.databinding.FragmentDoacaoBinding

class DoacaoFragment : Fragment() {
    private lateinit var binding: FragmentDoacaoBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDoacaoBinding.inflate(inflater, container, false)

        binding.etNome.setTextColor(resources.getColor(R.color.text_color_black, null))
        binding.etQuantia.setTextColor(resources.getColor(R.color.text_color_black, null))
        binding.etCausa.setTextColor(resources.getColor(R.color.text_color_black, null))

        binding.btnEnviarDoacao.setOnClickListener {
            val nome = binding.etNome.text.toString()
            val quantia = binding.etQuantia.text.toString()
            val causa = binding.etCausa.text.toString()

            if (nome.isNotEmpty() && quantia.isNotEmpty() && causa.isNotEmpty()) {
                val sharedPreferences = requireActivity().getSharedPreferences("Doacoes", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                val doacoes = sharedPreferences.getStringSet("doacoes", mutableSetOf()) ?: mutableSetOf()

                val doacao = "$nome|$quantia|$causa"
                doacoes.add(doacao)
                editor.putStringSet("doacoes", doacoes)
                editor.apply()

                Toast.makeText(requireContext(), "Doação enviada!", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_doacaoFragment_to_listaDoacoesFragment)
            } else {
                Toast.makeText(requireContext(), "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }
}
