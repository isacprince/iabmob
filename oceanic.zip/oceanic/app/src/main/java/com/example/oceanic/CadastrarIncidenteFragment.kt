package com.example.oceanic

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.oceanic.databinding.FragmentCadastrarIncidenteBinding

class CadastrarIncidenteFragment : Fragment() {
    private lateinit var binding: FragmentCadastrarIncidenteBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCadastrarIncidenteBinding.inflate(inflater, container, false)

        binding.etTitulo.setTextColor(resources.getColor(R.color.text_color_black, null))
        binding.etCoordenadas.setTextColor(resources.getColor(R.color.text_color_black, null))
        binding.etDescricao.setTextColor(resources.getColor(R.color.text_color_black, null))

        binding.btnEnviarIncidente.setOnClickListener {
            val titulo = binding.etTitulo.text.toString()
            val coordenadas = binding.etCoordenadas.text.toString()
            val descricao = binding.etDescricao.text.toString()

            if (titulo.isNotEmpty() && coordenadas.isNotEmpty() && descricao.isNotEmpty()) {
                val sharedPreferences = requireActivity().getSharedPreferences("Incidentes", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                val incidentes = sharedPreferences.getStringSet("incidentes", mutableSetOf()) ?: mutableSetOf()

                val incidente = "$titulo|$coordenadas|$descricao|PENDENTE"
                incidentes.add(incidente)
                editor.putStringSet("incidentes", incidentes)
                editor.apply()

                Toast.makeText(requireContext(), "Incidente enviado com sucesso!", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_cadastrarIncidenteFragment_to_homeFragment)
            } else {
                Toast.makeText(requireContext(), "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        return binding.root
    }
}
