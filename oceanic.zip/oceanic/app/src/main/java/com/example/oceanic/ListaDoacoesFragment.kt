package com.example.oceanic

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.oceanic.databinding.FragmentListaDoacoesBinding

class ListaDoacoesFragment : Fragment() {
    private lateinit var binding: FragmentListaDoacoesBinding
    private lateinit var adapter: DoacaoAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentListaDoacoesBinding.inflate(inflater, container, false)

        val sharedPreferences = requireActivity().getSharedPreferences("Doacoes", Context.MODE_PRIVATE)
        val doacoesSet = sharedPreferences.getStringSet("doacoes", mutableSetOf()) ?: mutableSetOf()
        val doacoes = doacoesSet.map {
            val parts = it.split("|")
            Doacao(parts[0], parts[1].toDouble(), parts[2])
        }

        adapter = DoacaoAdapter(doacoes)
        binding.rvDoacoes.layoutManager = LinearLayoutManager(requireContext())
        binding.rvDoacoes.adapter = adapter

        return binding.root
    }
}
